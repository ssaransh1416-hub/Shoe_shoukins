Shoe Shoukins v2

Files:
- index.html = public website
- admin.html = simple product manager

Important:
This version's admin data uses browser localStorage. It is useful for testing and for managing products on the same browser/device, but it does NOT publish product changes to every visitor.

For a real store, the next upgrade should use a database/backend so product changes are public everywhere.
